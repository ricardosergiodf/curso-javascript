console.log(12 > 5);
console.log(4 <= 4);
console.log("Matheus" != "João");
