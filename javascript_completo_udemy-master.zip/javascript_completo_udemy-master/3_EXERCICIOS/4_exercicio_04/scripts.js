console.log(3 == 3 && 4 > 1);
console.log(4 <= 2 || "Matheus" == "Pedro");
console.log(!(2 === 2));