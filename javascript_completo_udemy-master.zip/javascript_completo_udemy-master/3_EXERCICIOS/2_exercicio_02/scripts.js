console.log(235);
console.log(13.5);
console.log((3 * (12 + 4)) / 8);