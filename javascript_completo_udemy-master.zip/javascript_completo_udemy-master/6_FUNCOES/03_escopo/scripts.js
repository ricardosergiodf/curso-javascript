let y = 10;

function imprimir() {
  let y = 150;

  console.log(y);
}

imprimir();

console.log(y);
