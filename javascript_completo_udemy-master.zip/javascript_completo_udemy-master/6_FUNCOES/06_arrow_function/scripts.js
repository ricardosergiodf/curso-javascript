let consoleTeste = () => {
  console.log("Olá mundo!");
};

consoleTeste();

let soma = (a,b) => {
  return a + b;
};

console.log(soma(10,20));