let itens = document.querySelectorAll('.itens-vermelhos');

console.log(itens[0].style.color);

itens[0].style.color = 'red';

console.log(itens[0].style.color);

let itens2 = document.querySelectorAll('.itens-azuis');

console.log(itens2);