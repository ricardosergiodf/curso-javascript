let elemento = document.querySelector('#titulo-principal');

console.log(elemento.getBoundingClientRect());