let pSemTexto = document.getElementById("sem-texto");

let texto = document.createTextNode("Inserir este texto");

pSemTexto.appendChild(texto);