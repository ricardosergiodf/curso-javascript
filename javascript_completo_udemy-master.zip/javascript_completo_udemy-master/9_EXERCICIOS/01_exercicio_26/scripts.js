let numeros = [5,10,15,20,25];

console.log(numeros[0]);
console.log(numeros[2]);
console.log(numeros[3]);