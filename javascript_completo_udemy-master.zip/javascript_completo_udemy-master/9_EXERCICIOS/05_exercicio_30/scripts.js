let names = ["João", "Maria", "José", "Matheus", "Rodrigo"];

if(names.includes("Salete")) {
  console.log("O nome foi encontrado");
} else {
  console.log("O nome não foi encontrado");
}