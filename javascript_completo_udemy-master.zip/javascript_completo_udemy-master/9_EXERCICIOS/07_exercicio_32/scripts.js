let frutas = ["Maçã", "Banana", "Melão", "Melância", "Laranja"];

for(let i = 0; i < frutas.length; i++) {
  console.log(frutas[i]);
}