function potencia(a,b) {
  // return Math.pow(a,b);
  return a ** b;
}

console.log(potencia(2,2));
console.log(potencia(3,2));
console.log(potencia(4,4));
console.log(potencia(5,2));