function podeEntrarNaAuto(idade) {

  if(idade >= 18) {

    console.log("Pode se matricular na auto escola");

  } else {

    console.log("Não pode se matricular na auto escola");

  }

}

podeEntrarNaAuto(16);
podeEntrarNaAuto(25);
podeEntrarNaAuto(17);
podeEntrarNaAuto(18);