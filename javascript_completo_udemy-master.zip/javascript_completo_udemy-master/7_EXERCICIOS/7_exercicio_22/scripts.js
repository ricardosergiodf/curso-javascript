function numeroPos(numNegativo) {
  return Math.abs(numNegativo);
}

console.log(numeroPos(-13));
console.log(numeroPos(5));
console.log(numeroPos(-34.4));