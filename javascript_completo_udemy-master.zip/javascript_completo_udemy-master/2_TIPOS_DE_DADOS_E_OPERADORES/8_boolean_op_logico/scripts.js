console.log(5 > 3 && 3 == 2);
console.log(5 > 3 || 3 == 1);

console.log(3 == 3 && "Matheus" == "Matheus");
console.log("Felipe" == "João" || false);

console.log(!(!(true && true)));

console.log(true && true);
console.log(false || false);