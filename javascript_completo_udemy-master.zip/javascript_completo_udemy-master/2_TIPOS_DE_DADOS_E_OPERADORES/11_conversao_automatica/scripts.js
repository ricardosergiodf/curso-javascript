console.log(typeof ("123" + 4));
console.log(typeof ("30" - 20));
console.log(typeof ("ausd" * 3));