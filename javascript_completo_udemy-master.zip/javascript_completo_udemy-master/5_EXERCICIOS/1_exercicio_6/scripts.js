let nome = "Matheus";
let idade = 28;
let cnh = true;

console.log(typeof nome);
console.log(typeof idade);
console.log(typeof cnh);