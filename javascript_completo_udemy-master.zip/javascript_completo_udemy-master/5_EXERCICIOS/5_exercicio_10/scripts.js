let vel = 55;

if(vel > 80) {
  console.log("Levou multa");
} else {
  console.log("Não levou multa");
}