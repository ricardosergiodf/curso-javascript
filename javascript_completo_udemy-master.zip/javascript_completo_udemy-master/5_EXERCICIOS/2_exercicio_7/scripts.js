let idade = 15;

if(idade >= 18) {
  console.log("Pode entrar!");
}