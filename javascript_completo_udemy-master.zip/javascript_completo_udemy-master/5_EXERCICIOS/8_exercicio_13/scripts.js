for(let i = 100; i >= 50; i--) {
  console.log(i);
}