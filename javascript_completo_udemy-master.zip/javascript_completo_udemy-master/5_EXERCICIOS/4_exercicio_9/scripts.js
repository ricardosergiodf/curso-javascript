const num = 18;

console.log(Math.pow(2,2));
console.log(Math.pow(3,2));
console.log(Math.pow(num,2));