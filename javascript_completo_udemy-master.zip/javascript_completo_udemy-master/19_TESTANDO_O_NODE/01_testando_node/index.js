let msg = "Hello World!";

console.log(msg);