let maior = Math.max(6,12,28,55,8);

console.log(maior);

let menor = Math.min(6,12,28,55,8);

console.log(menor);

let arredondar = Math.round(5.2934723);

console.log(arredondar);

let arredondarParaCima = Math.ceil(5.2934723);

console.log(arredondarParaCima);