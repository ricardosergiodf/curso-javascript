// let if = 'Teste';
// let function = 'teste';
let functionTest = 'teste';
let function1 = 'teste2';

console.log(functionTest);
console.log(function1);