let idade = 28;
let nome = "Matheus";

console.log(idade);
console.log(nome);

console.log(`O meu nome é ${nome}, e tenho ${idade} anos`);