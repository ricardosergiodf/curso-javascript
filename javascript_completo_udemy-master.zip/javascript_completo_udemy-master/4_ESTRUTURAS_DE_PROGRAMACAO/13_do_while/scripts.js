let x = 100;

do {
  console.log(x/2);
  x = x - 5;
} while(x >= 0);


// while() {

// }