let nome = "Matheus";

console.log(nome);
console.log(`O meu nome é ${nome}`);

let laranjas = 5;

console.log(laranjas * laranjas);

nome = "João";

console.log(nome);

laranja = 83284;

console.log(laranja);

laranja = "Laranja";

console.log(laranja);

let um = 1, dois = 2, tres = 3;

console.log(um + dois + tres);