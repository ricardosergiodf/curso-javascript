let carros = ["BMW", "Fiat", "VW", "Renault", "Audi"];

console.log(carros.reverse());

let nums = [1,2,3,45,6,7,7];

console.log(nums.reverse());