let arr = [1, 4, 5, 6, 7];
let nomes = ['Matheus', 'João', 'Aléxia'];
let bool = [true, false, true];

let misturado = [1, 'Matheus', true];

console.log(arr);
console.log(nomes);
console.log(bool);
console.log(misturado);