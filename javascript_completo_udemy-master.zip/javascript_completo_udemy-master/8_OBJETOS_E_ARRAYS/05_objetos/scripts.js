let cachorro = {
  patas: 4,
  nome: 'Shark',
  latir: function() {
    console.log("Au Au");
  }
};

console.log(cachorro.patas);
console.log(cachorro.nome);
cachorro.latir();

// [] = array
// {} = obj