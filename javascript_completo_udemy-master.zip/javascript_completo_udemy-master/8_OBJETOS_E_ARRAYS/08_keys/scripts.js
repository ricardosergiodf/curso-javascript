let obj = {
  'chave1': 1,
  'chave2': 2,
  'chave3': 3,
}

console.log(obj);

console.log(Object.keys(obj));