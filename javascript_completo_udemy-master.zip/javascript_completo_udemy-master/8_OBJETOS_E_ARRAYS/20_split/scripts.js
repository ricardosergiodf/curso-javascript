let frase = "Testando o método split";

console.log(frase.split(" "));

let palavras = frase.split(" ");

console.log(palavras);

let produtos = "Banana;Maçã;Jaca;Pera;Bola;Tapete";

console.log(produtos.split(';'));