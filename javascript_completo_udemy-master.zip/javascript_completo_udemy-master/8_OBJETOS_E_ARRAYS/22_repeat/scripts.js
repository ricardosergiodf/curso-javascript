let palavra = "Repetir a frase ";

console.log(palavra.repeat(2));