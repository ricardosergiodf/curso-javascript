const cachorro = {
  uivar: function() {
    console.log("Auuuuuuuuuuuu");
  },
  rosnar: function() {
    console.log("grrrrr");
  }
}

cachorro.uivar();
cachorro.rosnar();